public class Coord {
    public double x = 0;
    public double y = 0;
    
    Coord (double xVal, double yVal) { 
        x = xVal;
        y = yVal;
    }
}
