import java.io.Serializable;

public class Lock extends Object implements Serializable {
    
}
