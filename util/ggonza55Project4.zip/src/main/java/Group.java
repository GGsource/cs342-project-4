public class Group {
    int ndx = -5;
    Group(int givenNdx) {
        ndx = givenNdx;
    }
}
